import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './Frame8.module.css';

interface Props {
  className?: string;
}
/* @figmaId 127:2 */
export const Frame8: FC<Props> = memo(function Frame8(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.image32}></div>
      <div className={classes.cynthiaArenas}>Cynthia Arenas</div>
      <div className={classes.camilaFuentes}>Camila Fuentes</div>
      <div className={classes.alejandraCamacaro}>Alejandra Camacaro</div>
      <div className={classes.QUIENESSOMOS}>¿QUIENES SOMOS?</div>
      <div className={classes.rectangle2}></div>
      <div className={classes.iNICIO}>INICIO</div>
      <div className={classes.somosUnEquipoComprometidoConEl}>
        Somos un equipo comprometido con el medio ambiente y creemos en la importancia de educar a los niños, sobre la
        sostenibilidad. Nos proponemos desarrollar una página web interactiva que sirva como herramienta educativa, con
        el objetivo de fomentar en los niños el cuidado y la protección del medio ambiente. A través de esta plataforma,
        buscamos proporcionar recursos educativos y actividades interactivas diseñadas para inspirar y motivar a los
        niños a adoptar prácticas responsables que promuevan la conservación de nuestro planeta.
      </div>
      <div className={classes.foto1}></div>
      <div className={classes.mariaPazVelozo}>María Paz Velozo</div>
      <div className={classes.image34}></div>
      <div className={classes.image35}></div>
      <div className={classes.image36}></div>
    </div>
  );
});
